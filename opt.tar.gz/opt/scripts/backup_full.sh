#!/bin/bash

function ayuda() {
    echo "Uso: $0 <directorio_origen> <directorio_destino>"
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo "Este script crea un archivo .tar.gz con nombre basado en la carpeta de origen y la fecha actual."
    echo "Opciones:"
    echo "  -help          Muestra esta ayuda."
}

if [[ "$1" == "-help" || "$1" == "--help" ]]; then
    ayuda
    exit 0
fi

if [[ $# -ne 2 ]]; then
    echo "Error: Se requieren 2 argumentos."
    ayuda
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe o no está montado."
    exit 2
fi

if [[ ! -d "$DESTINO" ]]; then
    echo "Error: El directorio de destino '$DESTINO' no existe o no está montado."
    exit 3
fi

FECHA=$(date +%Y%m%d)
NOMBRE_ORIGEN=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE_ORIGEN}_bkp_${FECHA}.tar.gz"

tar -czf "${DESTINO}/${ARCHIVO}" -C "$(dirname "$ORIGEN")" "$NOMBRE_ORIGEN"

if [[ $? -eq 0 ]]; then
    echo "Backup exitoso: ${DESTINO}/${ARCHIVO}"
else
    echo "Error durante el backup."
    exit 4
fi

exit 0
